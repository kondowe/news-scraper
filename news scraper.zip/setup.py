URL = "https://www.ap.com/"
SEARCH_PHRASE = "business"
NUMBER_OF_MONTHS = 1
CATEGORY = []
